var socket;
var img;

function setup() {
    createCanvas(500, 2000);
    socket = io.connect('http://localhost:3000');
    socket.emit('drawings');
    socket.on('combineImg', displayImg);
}
  
function displayImg(data) {
  let j = 0;
  for(let i = 0; i <= 3; i++) {
    data[i].forEach((value, index, array) => {
      if(value.e) {
        erase();
      } else {
        noErase();
      }
      line(value.x, value.y+j, value.px, value.py+j);
      strokeWeight(value.v);
      stroke(value.c);
    })
    j = j + 500;
  }
  img = get();
  img.resize(250,1000);
  background(255);
  image(img,250,0);
  noLoop();
}

function draw() {
  
}

  